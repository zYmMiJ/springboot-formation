package nc.sf2i.formation.excercice1spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Excercice1SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Excercice1SpringApplication.class, args);
	}

}
