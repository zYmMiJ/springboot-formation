package nc.sf2i.formation.excercice1spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Excercice1SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
