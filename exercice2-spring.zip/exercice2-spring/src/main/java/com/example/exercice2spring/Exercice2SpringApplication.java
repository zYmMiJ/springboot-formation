package com.example.exercice2spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercice2SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Exercice2SpringApplication.class, args);
	}

}
