package com.example.exercice2spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercice2SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
