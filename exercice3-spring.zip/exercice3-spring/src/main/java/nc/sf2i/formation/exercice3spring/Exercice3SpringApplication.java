package nc.sf2i.formation.exercice3spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercice3SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Exercice3SpringApplication.class, args);
	}

}
