package nc.sf2i.formation.exercice3spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercice3SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
