package nc.opt.formation.exercice4spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercice4SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Exercice4SpringApplication.class, args);
	}

}
