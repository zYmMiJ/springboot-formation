package nc.opt.formation.exercice4spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercice4SpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
