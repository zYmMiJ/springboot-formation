package nc.sf2i.formation.exercice5spring;

import java.time.LocalDate;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import nc.sf2i.formation.exercice5spring.entity.Address;
import nc.sf2i.formation.exercice5spring.entity.Event;
import nc.sf2i.formation.exercice5spring.entity.Guest;
import nc.sf2i.formation.exercice5spring.entity.Item;
import nc.sf2i.formation.exercice5spring.entity.User;
import nc.sf2i.formation.exercice5spring.repository.EventRepository;

@SpringBootApplication
public class Exercice5SpringApplication implements CommandLineRunner{
	@Autowired
	protected ApplicationContext context;
	
	public static void main(String[] args) {
		SpringApplication.run(Exercice5SpringApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// enregistrer l'event formation SpringBoot
		Address address = new Address();
		address.setName("OPT formation");
		address.setComments("Xyris");
		address.setStreet("Centre de Tri Postal");
		address.setCity("Noumea");
		address.setZipCode("98800");
		
		Event event = new Event();
		event.setTitle("Formation SpringBoot");
		event.setAddress(address);
		event.setDescription("Formation Spring, gradle, jhipster");
		event.setBeginDate(LocalDate.of(2020, 11, 2));
		event.setAllDays(true);
		address.setEvent(event);
		
		User user = new User();
		user.setLogin("tchao");
		user.setEmail("gaspard.tchao@sf2i.nc");
		user.setPass("gaspard");
		user.setEvents(Set.of(event));
		event.setUser(user);
		
		Item item1 = new Item();
		item1.setName("Video projecteur");
		item1.setCurrentQuanttiy(1);
		item1.setNeededQUantity(1);
		item1.setEvent(event);
		
		Item item2 = new Item();
		item2.setName("Barre de son");
		item2.setCurrentQuanttiy(1);
		item2.setNeededQUantity(1);
		item2.setEvent(event);
		event.setItems(Set.of(item1, item2));
		
		Guest guest1 = new Guest();
		guest1.setName("Raitapo");
		guest1.setEmail("joe.raitapo@sf2i.nc");
		guest1.setEvents(Set.of(event));
		
		Guest guest2 = new Guest();
		guest2.setName("Tartines");
		guest2.setEmail("kimberlee.tartines@sf2i.nc");
		guest2.setEvents(Set.of(event));
		event.setGuests(Map.of("joe.raitapo@sf2i.nc", guest1, "kimberlee.tartines@sf2i.nc", guest2));
		
		EventRepository repo = context.getBean(EventRepository.class);
		repo.save(event);
	}

}
