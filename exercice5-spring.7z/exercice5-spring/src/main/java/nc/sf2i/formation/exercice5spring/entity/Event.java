package nc.sf2i.formation.exercice5spring.entity;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
public class Event {
	@Id
	@Column(name = "event_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected Integer id;
	protected String title;
	protected String description;
	@Column(name = "begin_date")
	protected LocalDate beginDate;
	protected Boolean allDays;
	@OneToOne(mappedBy = "event", cascade = CascadeType.PERSIST)
	protected Address address;
	@Column(name ="users")
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "users")
	protected User user;
	@OneToMany(mappedBy = "event", cascade = CascadeType.PERSIST)
	protected Set<Item> items;
	@ManyToMany(cascade = CascadeType.PERSIST)
	@JoinTable(name = "guest_event",
			joinColumns = { @JoinColumn(name = "fk_event")},
			inverseJoinColumns = { @JoinColumn(name = "fk_guest")})
	@MapKey(name = "email")
	protected Map<String, Guest> guests;
	
	public Event() {
		items = new HashSet<Item>();
		guests = new HashMap<String, Guest>();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDate getBeginDate() {
		return beginDate;
	}

	public void setBeginDate(LocalDate beginDate) {
		this.beginDate = beginDate;
	}

	public Boolean getAllDays() {
		return allDays;
	}

	public void setAllDays(Boolean allDays) {
		this.allDays = allDays;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Set<Item> getItems() {
		return items;
	}

	public void setItems(Set<Item> items) {
		this.items = items;
	}

	public Map<String, Guest> getGuests() {
		return guests;
	}

	public void setGuests(Map<String, Guest> guests) {
		this.guests = guests;
	}
	
}
