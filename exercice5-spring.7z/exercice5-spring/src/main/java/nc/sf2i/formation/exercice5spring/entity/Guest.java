package nc.sf2i.formation.exercice5spring.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Guest {
	@Id
	@Column(name = "guest_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected Integer id;
	protected String name;
	protected String email;
	@ManyToMany(mappedBy = "guests")
	protected Set<Event> events;
	
	public Guest() {
		events = new HashSet<Event>();
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Set<Event> getEvents() {
		return events;
	}

	public void setEvents(Set<Event> events) {
		this.events = events;
	}
	
}
