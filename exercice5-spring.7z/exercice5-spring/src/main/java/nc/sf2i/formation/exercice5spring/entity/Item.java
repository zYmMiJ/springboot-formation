package nc.sf2i.formation.exercice5spring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Item {
	@Id
	@Column(name = "item_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected Integer id;
	protected String name;
	@Column(name = "current_quantity")
	protected Integer currentQuanttiy;
	@Column(name = "needed_quantity")
	protected Integer neededQUantity;
	@ManyToOne
	@JoinColumn(name = "event")
	protected Event event;
	
	public Item() {
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getCurrentQuanttiy() {
		return currentQuanttiy;
	}

	public void setCurrentQuanttiy(Integer currentQuanttiy) {
		this.currentQuanttiy = currentQuanttiy;
	}

	public Integer getNeededQUantity() {
		return neededQUantity;
	}

	public void setNeededQUantity(Integer neededQUantity) {
		this.neededQUantity = neededQUantity;
	}

	public Event getEvent() {
		return event;
	}

	public void setEvent(Event event) {
		this.event = event;
	}
	
}
