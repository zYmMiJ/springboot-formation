package nc.sf2i.formation.exercice5spring.repository;

import org.springframework.data.repository.CrudRepository;

import nc.sf2i.formation.exercice5spring.entity.Address;

public interface AddressRepository extends CrudRepository<Address, Integer> {

}
