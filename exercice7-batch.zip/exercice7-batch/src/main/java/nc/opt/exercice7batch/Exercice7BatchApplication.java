package nc.opt.exercice7batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercice7BatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(Exercice7BatchApplication.class, args);
	}

}
