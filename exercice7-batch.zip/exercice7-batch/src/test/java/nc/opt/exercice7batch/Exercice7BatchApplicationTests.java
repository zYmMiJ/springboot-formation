package nc.opt.exercice7batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercice7BatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
