package nc.opt.exercice8batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercice8BatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(Exercice8BatchApplication.class, args);
	}

}
