package nc.opt.exercice8batch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercice8BatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
